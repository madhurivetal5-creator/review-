'use client';

import { useEffect, useState } from 'react';
import Link from 'next/link';
import { brandVars, initials } from '@/lib/brand';
import { reviewUrl, posterPng, download } from '@/lib/qr-client';

const RATING_COLORS = { excellent: '#16a34a', good: '#84cc16', average: '#f59e0b', not_satisfied: '#ef4444' };
const RATING_LABELS = { excellent: 'Excellent', good: 'Good', average: 'Average', not_satisfied: 'Not satisfied' };

export default function AdminDashboard() {
  const [data, setData] = useState(null);
  const [error, setError] = useState('');

  const load = async () => {
    const res = await fetch('/api/admin/businesses', { cache: 'no-store' });
    if (res.status === 401) return (window.location.href = '/admin/login');
    const json = await res.json();
    if (!res.ok) setError(json.error || 'Could not load');
    else setData(json);
  };
  useEffect(() => {
    load();
  }, []);

  const logout = async () => {
    await fetch('/api/admin/logout', { method: 'POST' });
    window.location.href = '/admin/login';
  };

  if (error) return <div className="admin"><div className="alert warn">{error}</div></div>;
  if (!data) return <div className="admin"><p className="muted">Loading…</p></div>;

  const { businesses, stats } = data;
  const total = Object.values(stats).reduce(
    (a, s) => ({ visits: a.visits + s.visits, drafts: a.drafts + s.drafts, google: a.google + s.google_opens }),
    { visits: 0, drafts: 0, google: 0 }
  );

  return (
    <div className="admin">
      <div className="admin-top">
        <div>
          <h1>Smart Review Agent</h1>
          <p className="muted" style={{ margin: '4px 0 0' }}>
            {total.visits} visits · {total.drafts} drafts generated · {total.google} opened Google
          </p>
        </div>
        <div className="pills">
          <span className={'pill ' + (data.storage === 'supabase' ? 'ok' : 'warn')}>
            {data.storage === 'supabase' ? 'Database: Supabase' : 'Database: local file (testing only)'}
          </span>
          <span className={'pill ' + (data.ai ? 'ok' : 'warn')}>
            {data.ai ? `AI: Gemini (${data.model})` : 'AI: not configured – using basic templates'}
          </span>
          <button className="btn small" onClick={logout}>Log out</button>
        </div>
      </div>

      {data.storage !== 'supabase' && (
        <div className="alert warn">
          Supabase is not connected, so changes and stats are saved to a local file. That is fine for testing, but on
          Vercel/Render the file is wiped on every restart. Add <b>SUPABASE_URL</b> and <b>SUPABASE_SERVICE_ROLE_KEY</b> before going live.
        </div>
      )}

      <div className="biz-grid">
        {businesses.map((b) => {
          const s = stats[b.slug];
          return (
            <div key={b.slug} className="biz-card" style={brandVars(b)}>
              <div className="band" />
              <div className="body">
                <div className="biz-head">
                  {b.logo_url ? <img className="avatar img" src={b.logo_url} alt="" /> : <div className="avatar">{initials(b.short_name || b.name)}</div>}
                  <div>
                    <h2>{b.short_name || b.name}</h2>
                    <div className="slug">/review/{b.slug}</div>
                  </div>
                </div>
                <div>
                  {b.google_review_url ? (
                    <span className="pill ok">✓ Google review link set</span>
                  ) : (
                    <span className="pill bad">! Add Google review link</span>
                  )}
                </div>
                <div className="mini-stats">
                  <div><b>{s.visits}</b><span>Visits</span></div>
                  <div><b>{s.drafts}</b><span>Drafts</span></div>
                  <div><b>{s.copies}</b><span>Copied</span></div>
                  <div><b>{s.google_opens}</b><span>To Google</span></div>
                </div>
                <div className="biz-actions">
                  <Link className="btn small primary" href={`/admin/${b.slug}`}>Edit</Link>
                  <a className="btn small" href={`/review/${b.slug}?preview=1`} target="_blank" rel="noreferrer">Preview</a>
                  <button
                    className="btn small"
                    onClick={async () => download(await posterPng(b, reviewUrl(b.slug)), `${b.slug}-review-qr-poster.png`)}
                  >
                    QR ↓
                  </button>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      <div className="section">
        <h2>Usage statistics</h2>
        <p className="muted" style={{ marginTop: 0, fontSize: 13 }}>
          Anonymous counts only – no review text or personal data is stored. Admin previews are not counted.
        </p>
        <div className="table-wrap">
          <table className="stats">
            <thead>
              <tr>
                <th>Business</th><th>Visits</th><th>QR scans</th><th>Visits 7d</th><th>Drafts</th><th>Drafts 7d</th>
                <th>Gemini drafts</th><th>Re-worded</th><th>Copied</th><th>Opened Google</th><th>Experience chosen</th><th>Review language</th>
              </tr>
            </thead>
            <tbody>
              {businesses.map((b) => {
                const s = stats[b.slug];
                const rTotal = Object.values(s.ratings).reduce((a, x) => a + x, 0);
                return (
                  <tr key={b.slug}>
                    <td><b>{b.short_name || b.name}</b></td>
                    <td>{s.visits}</td><td>{s.qr_scans}</td><td>{s.visits_7d}</td><td>{s.drafts}</td><td>{s.drafts_7d}</td>
                    <td>{s.ai_drafts}</td><td>{s.regenerations}</td><td>{s.copies}</td><td>{s.google_opens}</td>
                    <td title={Object.entries(s.ratings).map(([k, v]) => `${RATING_LABELS[k]}: ${v}`).join('\n')}>
                      <div className="bar">
                        {rTotal ? Object.entries(s.ratings).map(([k, v]) => (
                          <i key={k} style={{ width: `${(v / rTotal) * 100}%`, background: RATING_COLORS[k] }} />
                        )) : null}
                      </div>
                      <span className="muted" style={{ fontSize: 11 }}>
                        {Object.entries(s.ratings).map(([k, v]) => `${RATING_LABELS[k][0]}${k === 'not_satisfied' ? 'S' : ''}:${v}`).join(' ')}
                      </span>
                    </td>
                    <td>EN {s.languages.en} · MR {s.languages.mr} · HI {s.languages.hi}</td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
