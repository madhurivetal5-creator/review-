import { redirect, notFound } from 'next/navigation';
import { isAdmin } from '@/lib/auth';
import { SLUGS } from '@/lib/seed';
import BusinessEditor from '@/components/BusinessEditor';

export const dynamic = 'force-dynamic';
export const metadata = { title: 'Edit business – Smart Review Agent' };

export default async function EditPage({ params }) {
  if (!(await isAdmin())) redirect('/admin/login');
  const { slug } = await params;
  if (!SLUGS.includes(slug)) notFound();
  return <BusinessEditor slug={slug} />;
}
