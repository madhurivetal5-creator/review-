import { NextResponse } from 'next/server';
import { isAdmin } from '@/lib/auth';
import { getBusiness, updateBusiness } from '@/lib/store';
import { sanitizeBusiness } from '@/lib/validate';
import { getSeed } from '@/lib/seed';

export const dynamic = 'force-dynamic';

export async function GET(_req, { params }) {
  if (!(await isAdmin())) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  const { slug } = await params;
  const b = await getBusiness(slug);
  if (!b) return NextResponse.json({ error: 'Not found' }, { status: 404 });
  return NextResponse.json({ business: b, defaults: getSeed(slug) });
}

export async function PUT(req, { params }) {
  if (!(await isAdmin())) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  const { slug } = await params;
  const current = await getBusiness(slug);
  if (!current) return NextResponse.json({ error: 'Not found' }, { status: 404 });
  const input = await req.json().catch(() => null);
  if (!input) return NextResponse.json({ error: 'Invalid data' }, { status: 400 });
  const { errors, value, warning } = sanitizeBusiness(input, current);
  if (errors.length) return NextResponse.json({ error: errors.join(' ') }, { status: 400 });
  try {
    const saved = await updateBusiness(slug, value);
    return NextResponse.json({ business: saved, warning });
  } catch (e) {
    return NextResponse.json({ error: e.message }, { status: 500 });
  }
}
