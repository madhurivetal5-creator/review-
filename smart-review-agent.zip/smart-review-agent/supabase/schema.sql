-- Smart Google Review Agent – Supabase schema
-- Run this once in Supabase → SQL Editor → New query → paste → Run.
-- The app fills in the four businesses automatically on first load.

create table if not exists public.businesses (
  slug               text primary key
                     check (slug in ('jatan', 'dhruta', 'haemoglobbinn', 'makoons-wakad')),
  name               text not null,
  short_name         text,
  category           text,
  location           text,
  logo_url           text,
  primary_color      text default '#1F3A5F',
  accent_color       text default '#C9A227',
  google_review_url  text,          -- PUBLIC "write a review" link (g.page/r/.../review)
  gbp_manage_url     text,          -- management link, admin reference only
  seo_keywords       text,
  greeting           jsonb not null default '{}'::jsonb,
  questions          jsonb not null default '[]'::jsonb,
  updated_at         timestamptz not null default now()
);

create table if not exists public.review_events (
  id             bigserial primary key,
  business_slug  text not null references public.businesses(slug) on delete cascade,
  type           text not null check (type in ('visit', 'draft', 'regenerate', 'copy', 'google_open')),
  rating         text,
  language       text,
  source         text,
  created_at     timestamptz not null default now()
);
-- No review text and no personal data is stored – only anonymous counts.

create index if not exists review_events_slug_type_idx on public.review_events (business_slug, type);
create index if not exists review_events_created_idx on public.review_events (created_at);

-- Row Level Security ON with NO policies: the public (anon) key cannot read or
-- write anything. Only the server, using the service-role key, can.
alter table public.businesses enable row level security;
alter table public.review_events enable row level security;

create or replace view public.business_stats
with (security_invoker = true) as
select
  business_slug,
  count(*) filter (where type = 'visit')                                   as visits,
  count(*) filter (where type = 'visit' and source = 'qr')                 as qr_scans,
  count(*) filter (where type = 'draft')                                   as drafts,
  count(*) filter (where type = 'draft' and source = 'ai')                 as ai_drafts,
  count(*) filter (where type = 'regenerate')                              as regenerations,
  count(*) filter (where type = 'copy')                                    as copies,
  count(*) filter (where type = 'google_open')                             as google_opens,
  count(*) filter (where type = 'visit' and created_at > now() - interval '7 days') as visits_7d,
  count(*) filter (where type = 'draft' and created_at > now() - interval '7 days') as drafts_7d,
  count(*) filter (where type = 'draft' and rating = 'excellent')          as r_excellent,
  count(*) filter (where type = 'draft' and rating = 'good')               as r_good,
  count(*) filter (where type = 'draft' and rating = 'average')            as r_average,
  count(*) filter (where type = 'draft' and rating = 'not_satisfied')      as r_not_satisfied,
  count(*) filter (where type = 'draft' and language = 'en')               as l_en,
  count(*) filter (where type = 'draft' and language = 'mr')               as l_mr,
  count(*) filter (where type = 'draft' and language = 'hi')               as l_hi
from public.review_events
group by business_slug;

revoke all on public.business_stats from anon, authenticated;
